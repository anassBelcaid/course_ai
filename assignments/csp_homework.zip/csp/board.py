

import tkinter as tk
from PIL import Image, ImageTk


class ChessBoard:
    def __init__(self, root, queen_image_path, board_size=8):
        self.root = root
        self.board_size = board_size
        self.square_size = 640 // self.board_size

        self.canvas = tk.Canvas(root, width=640, height=640)
        self.canvas.pack()

        # Load and resize queen icon
        img = Image.open(queen_image_path).resize((self.square_size - 10, self.square_size - 10))
        self.queen_image = ImageTk.PhotoImage(img)

        # ⚠️ Hold a reference to prevent garbage collection
        self.image_refs = [self.queen_image]

        # State
        self.queens = {}
        self.not_possible = set()

        self.draw_board()

    def draw_board(self):
        self.canvas.delete("all")
        for row in range(self.board_size):
            for col in range(self.board_size):
                x1 = col * self.square_size
                y1 = row * self.square_size
                x2 = x1 + self.square_size
                y2 = y1 + self.square_size

                # Base color (red if not possible)
                color = "white" if (row + col) % 2 == 0 else "black"
                if (row, col) in self.not_possible:
                    color = "red"

                self.canvas.create_rectangle(x1, y1, x2, y2, fill=color)

                # Draw queen if placed
                if (row, col) in self.queens:
                    self.canvas.create_image(
                        x1 + self.square_size // 2,
                        y1 + self.square_size // 2,
                        image=self.queen_image
                    )

    def place_queen(self, row, col):
        if 0 <= row < self.board_size and 0 <= col < self.board_size:
            self.queens[(row, col)] = True
            self.draw_board()

    def remove_queen(self, row, col):
        if (row, col) in self.queens:
            del self.queens[(row, col)]
            self.draw_board()

    def mark_not_possible(self, row, col):
        if 0 <= row < self.board_size and 0 <= col < self.board_size:
            self.not_possible.add((row, col))
            self.draw_board()

    def clear_not_possible(self):
        self.not_possible.clear()
        self.draw_board()

    def reset_board(self):
        self.queens.clear()
        self.not_possible.clear()
        self.draw_board()
