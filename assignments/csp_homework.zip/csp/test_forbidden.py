
import tkinter as tk
import time
from board import ChessBoard
from csp import get_forbidden_squares


def test_forbidden_visual():
    root = tk.Tk()
    board = ChessBoard(root, "queen.png", board_size=8)

    def place_and_show(positions):
        board.reset_board()

        for (row, col) in positions:
            board.place_queen(row, col)

        forbidden = get_forbidden_squares(positions, board.board_size)

        for (row, col) in forbidden:
            if (row, col) not in positions:
                board.mark_not_possible(row, col)

        board.root.update()

    def step_by_step():
        # Step 1: One queen at (3, 3)
        place_and_show([(3, 3)])
        print("Placed queen at (3, 3)")
        time.sleep(2)

        # Step 2: Add another queen at (1, 5)
        place_and_show([(3, 3), (1, 5)])
        print("Placed queen at (1, 5)")
        time.sleep(2)

        # Step 3: Add third queen at (6, 1)
        place_and_show([(3, 3), (1, 5), (6, 1)])
        print("Placed queen at (6, 1)")
        time.sleep(2)

    root.after(500, step_by_step)
    root.mainloop()


if __name__ == "__main__":
    test_forbidden_visual()
