
if __name__ == "__main__":
    root = tk.Tk()
    board = ChessBoard(root, "queen.png", board_size=10)  # <- Change N here

    board.place_queen(0, 0)
    board.mark_not_possible(1, 1)
    board.mark_not_possible(2, 2)

    root.mainloop()
