import tkinter as tk
import time

class SudokuGUI:
    def __init__(self, root, board):
        self.root = root
        self.board = board
        self.cell_size = 50
        self.canvas = tk.Canvas(root, width=450, height=450, bg="white", highlightthickness=0)
        self.canvas.pack()
        self.draw_grid()
        self.fill_board()



    def fill_background(self):
        for row in range(9):
            for col in range(9):
                x1 = col * self.cell_size
                y1 = row * self.cell_size
                x2 = x1 + self.cell_size
                y2 = y1 + self.cell_size
                self.canvas.create_rectangle(x1, y1, x2, y2, fill="white", outline="")
    def show_board(self, initial=False):
        self.fill_background()
        for r in range(9):
            for c in range(9):
                val = self.board[r][c]
                if val != 0:
                    color = "black" if initial else "blue"
                    self.draw_number(r, c, val, color=color)
        self.draw_grid()  # Redraw borders on top
        self.root.update()
    def draw_grid(self):
        size = self.cell_size
        for i in range(10):
            width = 3 if i % 3 == 0 else 1
            # Horizontal lines
            self.canvas.create_line(0, i * size, 9 * size, i * size, fill="black", width=width)
            # Vertical lines
            self.canvas.create_line(i * size, 0, i * size, 9 * size, fill="black", width=width)

    def draw_number(self, row, col, num, color="black"):
        x = col * self.cell_size + self.cell_size // 2
        y = row * self.cell_size + self.cell_size // 2
        self.canvas.create_text(x, y, text=str(num), fill=color, font=("Helvetica", 20, "bold"))

    def fill_board(self):
        for r in range(9):
            for c in range(9):
                val = self.board[r][c]
                if val != 0:
                    self.draw_number(r, c, val)


def is_valid(board, row, col, num):
    # Row and column
    if any(board[row][i] == num for i in range(9)) or any(board[i][col] == num for i in range(9)):
        return False

    # 3x3 block
    start_row, start_col = 3 * (row // 3), 3 * (col // 3)
    for r in range(start_row, start_row + 3):
        for c in range(start_col, start_col + 3):
            if board[r][c] == num:
                return False
    return True


def find_empty_cell(board):
    """Find the next empty cell (row, col) or return None if full."""
    for r in range(9):
        for c in range(9):
            if board[r][c] == 0:
                return r, c
    return None


def get_possible_values(board, row, col):
    """Return a set of valid numbers for the given empty cell."""
    # Your code goes here
    pass


def solve_with_forward_checking(board):
    """Optimized Sudoku solver using forward checking."""
    # Your code goes here
    pass


if __name__ == "__main__":
    puzzle = [
        [5, 3, 0, 0, 7, 0, 0, 0, 0],
        [6, 0, 0, 1, 9, 5, 0, 0, 0],
        [0, 9, 8, 0, 0, 0, 0, 6, 0],

        [8, 0, 0, 0, 6, 0, 0, 0, 3],
        [4, 0, 0, 8, 0, 3, 0, 0, 1],
        [7, 0, 0, 0, 2, 0, 0, 0, 6],

        [0, 6, 0, 0, 0, 0, 2, 8, 0],
        [0, 0, 0, 4, 1, 9, 0, 0, 5],
        [0, 0, 0, 0, 8, 0, 0, 7, 9]
    ]

    root = tk.Tk()
    root.title("Sudoku Solver")

    # Show initial board
    gui = SudokuGUI(root, [row[:] for row in puzzle])  # Copy for initial state
    gui.show_board(initial=False)

    # After 3 seconds, solve and update board
    def solve_and_show():
        solve_with_forward_checking(puzzle)
        gui.board = puzzle
        gui.show_board(initial=False)

    root.after(3000, solve_and_show)
    root.mainloop()
