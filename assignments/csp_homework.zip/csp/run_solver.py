
import sys
import tkinter as tk
from board import ChessBoard
from csp import backtracking, forward_search, min_conflicts

def run(n, algorithm):
    root = tk.Tk()
    root.title(f"{algorithm} on {n}x{n} board")
    board = ChessBoard(root, "queen.png", board_size=n)

    def start():
        if algorithm == "backtracking":
            backtracking(board)
        elif algorithm == "forward_search":
            forward_search(board)

        elif algorithm == "min_conflicts":
            success = min_conflicts(board)
            print("Solved!" if success else "Failed!")
        else:
            print(f"Unknown algorithm: {algorithm}")

    root.after(500, start)
    root.mainloop()


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python run_solver.py <n> <algorithm>")
        print("Example: python run_solver.py 8 backtracking")
        sys.exit(1)

    n = int(sys.argv[1])
    algorithm = sys.argv[2].lower()
    run(n, algorithm)
