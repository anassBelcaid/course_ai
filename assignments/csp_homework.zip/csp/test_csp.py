import pytest
from csp import is_valid


@pytest.mark.is_valid
def test_valid_small_board():
    queens = {(0, 1): True, (1, 3): True, (2, 0): True, (3, 2): True}
    assert is_valid(queens)


@pytest.mark.is_valid
def test_invalid_same_column():
    queens = {(0, 0): True, (1, 0): True}
    assert not is_valid(queens)


@pytest.mark.is_valid
def test_invalid_same_diagonal():
    queens = {(0, 0): True, (1, 1): True}
    assert not is_valid(queens)


@pytest.mark.is_valid
def test_valid_large_board():
    queens = {(0, 0): True, (1, 4): True, (2, 7): True, (3, 5): True}
    assert is_valid(queens)


@pytest.mark.is_valid
def test_invalid_same_row():
    queens = {(2, 1): True, (2, 3): True}
    assert not is_valid(queens)
